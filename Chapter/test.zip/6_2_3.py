import cv2
import mycamera
import time

def main():
    cap = mycamera.MyPiCamera(640, 480)

    while True:
        _, frame = cap.read()
        frame = cv2.flip(frame, -1)

        height, width, channels = frame.shape
        save_image = frame[int(height/2):, :, :]
        save_image = cv2.cvtColor(save_image, cv2.COLOR_BGR2YUV)
        save_image = cv2.GaussianBlur(save_image, (3,3), 0)
        cv2.imshow('Save', save_image)

        cv2.imshow('Camera', frame)

        key = cv2.waitKey(10) & 0xFF
        if key == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
