import mycamera
import cv2
import torch
from ultralytics import YOLO
from gpiozero import PWMOutputDevice
import time

def beep_twice(buzzer):
    freqs = [1000, 1500]
    for f in freqs:
        buzzer.frequency = f
        buzzer.value = 0.5
        time.sleep(0.2)
        buzzer.value = 0
        time.sleep(0.1)

def draw_detections(frame, results, names):
    if results is None:
        return frame
    for b in results.boxes:
        cls_id = int(b.cls.item())
        conf = float(b.conf.item())
        x1, y1, x2, y2 = map(int, b.xyxy[0].tolist())
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        label = f"{names[cls_id]} {conf:.2f}"
        cv2.putText(frame, label, (x1, max(10, y1 - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    return frame

if __name__ == "__main__":
    model = YOLO('yolov8n.pt')
    camera = mycamera.MyPiCamera(640, 480)
    buzzer = PWMOutputDevice(12)
    prev_detected = False

    try:
        while camera.isOpened():
            ok, frame = camera.read()
            if not ok:
                break

            frame = cv2.flip(frame, -1)
            results = model(frame, imgsz=320, conf=0.5, iou=0.5, device='cpu')[0]
            person_detected = any(int(b.cls.item()) == 0 for b in results.boxes)

            if person_detected and not prev_detected:
                beep_twice(buzzer)

            prev_detected = person_detected
            out = draw_detections(frame, results, model.names)
            cv2.imshow('YOLOv8 (buzzer)', out)

            if cv2.waitKey(1) == ord('q'):
                break
    finally:
        buzzer.value = 0
        camera.release()
        cv2.destroyAllWindows()
