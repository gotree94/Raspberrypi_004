import sys
import torch
import cv2
import numpy as np

def main():
    print("===== Version Info =====")
    print(f"Python version: {sys.version.split()[0]}")
    print(f"Torch version: {torch.__version__}")
    print(f"OpenCV version: {cv2.__version__}")
    print(f"Numpy version: {np.__version__}")
    print("========================")

if __name__ == "__main__":
    main()
