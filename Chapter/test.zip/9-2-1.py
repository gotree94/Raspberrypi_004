import os
from datetime import datetime
import cv2
import mycamera

SAVE_DIR = os.path.join(os.path.dirname(__file__), "pictures")
os.makedirs(SAVE_DIR, exist_ok=True)

if __name__ == "__main__":
    camera = mycamera.MyPiCamera(640, 480)
    while camera.isOpened():
        ok, image = camera.read()
        if not ok:
            break
        image = cv2.flip(image, -1)
        cv2.imshow("mycamera", image)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('s'):
            filename = datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".png"
            path = os.path.join(SAVE_DIR, filename)
            cv2.imwrite(path, image)
            print(f'saved: {path}')
        elif key == ord('q'):
            break

    cv2.destroyAllWindows()
