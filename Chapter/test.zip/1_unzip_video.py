import zipfile
import os
import shutil

current_dir = os.path.dirname(os.path.abspath(__file__))
zip_path = os.path.join(current_dir, 'video.zip')
extract_folder = os.path.join(current_dir, 'video')

if os.path.exists(extract_folder):
    shutil.rmtree(extract_folder)

with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall(current_dir)

print("done")
