import os
import pickle
import matplotlib.pyplot as plt

model_folder = "."

history_path = os.path.join(model_folder, "history.pickle")
with open(history_path, "rb") as f:
    history = pickle.load(f)

print('History keys:', history.keys())

train_loss = history.get("train_loss", history.get("loss"))
val_loss = history.get("val_loss")
val_mae = history.get("val_mae")

plt.figure(figsize=(10, 5))
if train_loss is not None:
    plt.plot(train_loss, label="Training Loss")
if val_loss is not None:
    plt.plot(val_loss, label="Validation Loss")
plt.title("Model Training History - Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.grid(True)
plt.show()

if val_mae is not None:
    plt.figure(figsize=(10, 5))
    plt.plot(val_mae, label="Validation MAE")
    plt.title("Model Training History - MAE")
    plt.xlabel("Epoch")
    plt.ylabel("MAE (deg)")
    plt.legend()
    plt.grid(True)
    plt.show()
