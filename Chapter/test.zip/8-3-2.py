import mycamera
import torch
import cv2
import numpy as np

MODEL_PATH = "/home/pi/AI_CAR/model/lane_navigation_final.torchscript"

def img_preprocess(image):
    h, w, c = image.shape
    image = image[h//2:, :, :]
    image = cv2.cvtColor(image, cv2.COLOR_BGR2YUV)
    image = cv2.GaussianBlur(image, (3, 3), 0)
    image = cv2.resize(image, (200, 66))
    image = image.astype(np.float32) / 255.0
    return image

def main():
    camera = mycamera.MyPiCamera(640, 480)
    model = torch.jit.load(MODEL_PATH, map_location="cpu")
    model.eval()
    torch.set_num_threads(1)

    try:
        while camera.isOpened():
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

            ok, image = camera.read()
            if not ok:
                continue

            image = cv2.flip(image, -1)

            pre = img_preprocess(image)
            x = np.transpose(pre, (2, 0, 1))
            x = np.expand_dims(x, axis=0)
            x_tensor = torch.from_numpy(x).float()

            with torch.no_grad():
                y = model(x_tensor)

            angle = int(float(y.item()))
            print('predict angle:', angle)

            cv2.imshow("camera", image)
            cv2.imshow('preprocess', pre)

    finally:
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
