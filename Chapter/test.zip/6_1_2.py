import cv2
import numpy as np
import time
import myservo
from gpiozero import DigitalOutputDevice
from gpiozero import PWMOutputDevice

def nothing(x):
    pass

def main():
    pca9685 = myservo.PCA9685()
    channel = 0

    space_pressed = False

    cv2.namedWindow('Controls')
    cv2.resizeWindow('Controls', 500, 100)

    cv2.createTrackbar('Steering','Controls', 90, 180, nothing)
    cv2.createTrackbar('Speed','Controls', 40, 100, nothing)

    while True:
        steering_value = cv2.getTrackbarPos('Steering','Controls')
        speed_value = cv2.getTrackbarPos('Speed','Controls')

        servo_angle = pca9685.set_servo_angle(channel, steering_value)

        controls_image = np.zeros((100, 500, 3), dtype=np.uint8)
        cv2.putText(controls_image, f'Steering: {servo_angle}', (10,30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
        cv2.putText(controls_image, f'Speed: {speed_value}', (10,70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)

        if space_pressed:
            cv2.circle(controls_image, (250, 30), 15, (0,255,0), -1)
            cv2.putText(controls_image, 'GO', (235, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
        else:
            cv2.circle(controls_image, (250, 30), 15, (0,0,255), -1)
            cv2.putText(controls_image, 'STOP', (235, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)

        cv2.imshow('Controls', controls_image)

        key = cv2.waitKey(10) & 0xFF
        if key == ord('q'):
            break
        elif key == 32:  # Space key
            space_pressed = not space_pressed

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
